#include <stdlib.h>
#include <limits.h>

typedef struct
{
    float x;
    float y;
} Point;
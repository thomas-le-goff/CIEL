#include <M5Unified.h>
#include <esp_timer.h>
#define LV_CONF_INCLUDE_SIMPLE
#include <lvgl.h>

#include "lvgl_freertos_glue.hpp"

namespace lfg_m5
{
  constexpr int32_t HOR_RES = 320;
  constexpr int32_t VER_RES = 240;

  static lv_display_t *display;
  static lv_indev_t *indev;

  static void flush_cb(lv_display_t *disp, const lv_area_t *area, uint8_t *px_map)
  {
    uint32_t w = (area->x2 - area->x1 + 1);
    uint32_t h = (area->y2 - area->y1 + 1);

    lv_draw_sw_rgb565_swap(px_map, w * h);
    M5.Display.pushImageDMA<uint16_t>(area->x1, area->y1, w, h, (uint16_t *)px_map);
    lv_disp_flush_ready(disp);
  }

  uint32_t tick_function_cb()
  {
    return (esp_timer_get_time() / 1000LL);
  }

  static void touchpad_read_cb(lv_indev_t *drv, lv_indev_data_t *data)
  {
    M5.update();
    auto count = M5.Touch.getCount();

    if (count == 0)
    {
      data->state = LV_INDEV_STATE_RELEASED;
    }
    else
    {
      auto touch = M5.Touch.getDetail(0);
      data->state = LV_INDEV_STATE_PRESSED;
      data->point.x = touch.x;
      data->point.y = touch.y;
    }
  }

  void init(void)
  {
    lv_init();

    lv_tick_set_cb(tick_function_cb);

    display = lv_display_create(HOR_RES, VER_RES);
    lv_display_set_flush_cb(display, flush_cb);

    static uint8_t buf[HOR_RES * VER_RES / 10 * 2];
    lv_display_set_buffers(display, buf, nullptr, sizeof(buf), LV_DISPLAY_RENDER_MODE_PARTIAL);

    indev = lv_indev_create();
    lv_indev_set_type(indev, LV_INDEV_TYPE_POINTER);

    lv_indev_set_read_cb(indev, touchpad_read_cb);
  }

  void update(void)
  {
    lv_task_handler();
  }
}

#pragma once

namespace lfg_m5 {
    void init(void);
    void update(void);
}